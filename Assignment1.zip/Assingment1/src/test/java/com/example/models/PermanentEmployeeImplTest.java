// PermanentEmployeeImplTest.java
public class PermanentEmployeeImplTest {
    @Test
    public void testCalculateSalary() {
        // Test logic
    }

    @Test
    public void testCalculateBonus() {
        // Test logic
    }

    @Test
    public void testCalculatePension() {
        // Test logic
    }
}

// ContractEmployeeImplTest.java
public class ContractEmployeeImplTest {
    @Test
    public void testCalculateSalary() {
        // Test logic
    }

    @Test
    public void testCalculateRenewalDate() {
        // Test logic
    }
}

// PersistenceServiceTest.java
public class PersistenceServiceTest {
    @Test
    public void testSave() {
        // Test logic
    }
}