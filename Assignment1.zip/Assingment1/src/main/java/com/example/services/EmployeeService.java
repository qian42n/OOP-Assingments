package com.example.services;

public class EmployeeService {
    // Employee service methods
}