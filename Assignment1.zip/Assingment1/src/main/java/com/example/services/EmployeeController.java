package com.example.services;

import com.example.models.Employee;
import com.example.formatters.Formatter;

public class EmployeeController {
    private Employee employee;
    private Formatter formatter;
    private PersistenceService persistenceService;

    public EmployeeController(Employee employee, Formatter formatter, PersistenceService persistenceService) {
        this.employee = employee;
        this.formatter = formatter;
        this.persistenceService = persistenceService;
    }

    public void saveEmployee(Employee employee) {
        String formattedData = formatter.format(employee);
        persistenceService.save(formattedData);
    }
}