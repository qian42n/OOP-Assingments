package com.example;

import com.example.models.ContractEmployeeImpl;
import com.example.models.PermanentEmployeeImpl;
import com.example.models.Employee;
import com.example.services.EmployeeController;
import com.example.services.PersistenceService;
import com.example.formatters.JSONFormatter;
import com.example.formatters.TextFormatter;
import com.example.formatters.Formatter;

public class Main {
    public static void main(String[] args) {
        Employee permanentEmployee = new PermanentEmployeeImpl("John Doe", "john@example.com", 50000, 5);
        Employee contractEmployee = new ContractEmployeeImpl("Jane Smith", "jane@example.com", 40000);

        Formatter jsonFormatter = new JSONFormatter();
        Formatter textFormatter = new TextFormatter();
        PersistenceService persistenceService = new PersistenceService();

        EmployeeController jsonController = new EmployeeController(permanentEmployee, jsonFormatter, persistenceService);
        EmployeeController textController = new EmployeeController(contractEmployee, textFormatter, persistenceService);

        jsonController.saveEmployee(permanentEmployee);
        textController.saveEmployee(contractEmployee);

        System.out.println(jsonFormatter.format(permanentEmployee));
        System.out.println(textFormatter.format(contractEmployee));
    }
}