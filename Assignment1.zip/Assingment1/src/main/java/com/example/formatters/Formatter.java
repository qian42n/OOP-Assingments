package com.example.formatters;

import com.example.models.Employee;

public interface Formatter {
    String format(Employee employee);
}