package com.example.formatters;

import com.example.models.Employee;
import com.google.gson.Gson;

public class JSONFormatter implements Formatter {
    private Gson gson = new Gson();

    @Override
    public String format(Employee employee) {
        return gson.toJson(employee);
    }
}