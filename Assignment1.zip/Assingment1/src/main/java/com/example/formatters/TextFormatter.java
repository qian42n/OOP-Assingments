package com.example.formatters;

import com.example.models.Employee;

public class TextFormatter implements Formatter {
    @Override
    public String format(Employee employee) {
        return "Name: " + employee.getName() + ", Email: " + employee.getEmail() + ", Salary: " + employee.getSalary();
    }
}