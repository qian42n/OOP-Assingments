package com.example.models;

public class ContractEmployeeImpl extends Employee {
    private double salary;

    public ContractEmployeeImpl(String name, String email, double salary) {
        super(name, email);
        this.salary = salary;
    }

    @Override
    public double getSalary() {
        return salary;
    }
}