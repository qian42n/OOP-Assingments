package com.example.models;

public class PermanentEmployeeImpl extends Employee {
    private double salary;
    private int yearsOfService;

    public PermanentEmployeeImpl(String name, String email, double salary, int yearsOfService) {
        super(name, email);
        this.salary = salary;
        this.yearsOfService = yearsOfService;
    }

    @Override
    public double getSalary() {
        return salary;
    }

    public int getYearsOfService() {
        return yearsOfService;
    }
}