package assignment1;

public class VehicleDirector {
    // Method to construct a vehicle using the builder
    public Vehicle constructVehicle(VehicleBuilder builder) {
        builder.buildEngine();
        builder.buildWheels();
        return builder.getVehicle();
    }
}
