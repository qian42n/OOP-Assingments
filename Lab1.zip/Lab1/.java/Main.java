package assignment1;

public class Main {
    public static void main(String[] args) {
        // Verify Singleton pattern
        VehicleManager manager = VehicleManager.getInstance();
        
        // Use Simple Factory pattern to create vehicles
        Vehicle car = VehicleFactory.createVehicle("car", "Toyota", "Corolla");
        Vehicle motorcycle = VehicleFactory.createVehicle("motorcycle", "Honda", "CBR");

        manager.addVehicle(car);
        manager.addVehicle(motorcycle);

        // Verify Builder pattern
        VehicleBuilder carBuilder = new CarBuilder("Ford", "Mustang");
        VehicleDirector director = new VehicleDirector();
        Vehicle fordCar = director.constructVehicle(carBuilder);
        manager.addVehicle(fordCar);

        // Display all vehicles
        for (Vehicle vehicle : manager.getVehicles()) {
            vehicle.start();
        }

        // Verify Singleton property
        VehicleManager manager2 = VehicleManager.getInstance();
        System.out.println("Are both managers the same? " + (manager == manager2));
    }
}
