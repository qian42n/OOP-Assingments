package assignment1;

public class CarBuilder implements VehicleBuilder {
    private String make;
    private String model;
    private Vehicle car;

    public CarBuilder(String make, String model) {
        this.make = make;
        this.model = model;
    }

    @Override
    public void buildEngine() {
        System.out.println("Building engine for " + make + " " + model);
    }

    @Override
    public void buildWheels() {
        System.out.println("Building wheels for " + make + " " + model);
    }

    @Override
    public Vehicle getVehicle() {
        car = new Vehicle(make, model) {};
        return car;
    }
}
