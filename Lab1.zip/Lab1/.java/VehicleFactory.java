package assignment1;

public class VehicleFactory {
    // Method to create a vehicle based on the type
    public static Vehicle createVehicle(String type, String make, String model) {
        switch (type.toLowerCase()) {
            case "car":
                return new Vehicle(make, model) {
                    @Override
                    public void start() {
                        System.out.println(make + " " + model + " car is starting.");
                    }
                };
            case "motorcycle":
                return new Vehicle(make, model) {
                    @Override
                    public void start() {
                        System.out.println(make + " " + model + " motorcycle is starting.");
                    }
                };
            default:
                throw new IllegalArgumentException("Unknown vehicle type: " + type);
        }
    }
}
