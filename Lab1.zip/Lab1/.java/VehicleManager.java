package assignment1;

import java.util.ArrayList;
import java.util.List;

public class VehicleManager {
    private static VehicleManager instance;  // Singleton instance
    private List<Vehicle> vehicles;          // List to store vehicles

    // Private constructor to prevent multiple instantiations
    private VehicleManager() {
        vehicles = new ArrayList<>();
    }

    // Method to get the singleton instance of VehicleManager
    public static VehicleManager getInstance() {
        if (instance == null) {
            instance = new VehicleManager();
        }
        return instance;
    }

    // Method to add a vehicle to the manager
    public void addVehicle(Vehicle vehicle) {
        vehicles.add(vehicle);
    }

    // Method to retrieve the list of vehicles
    public List<Vehicle> getVehicles() {
        return vehicles;
    }
}
