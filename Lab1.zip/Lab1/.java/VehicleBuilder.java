package assignment1;

import assignment1.Vehicle;

public interface VehicleBuilder {
    void buildEngine();
    void buildWheels();
    Vehicle getVehicle();
}
