package assignment1;

public abstract class Vehicle {
    private String make;
    private String model;

    public Vehicle(String make, String model) {
        this.make = make;
        this.model = model;
    }

    // Method to start the vehicle
    public void start() {
        System.out.println(make + " " + model + " is starting.");
    }

    // Method to stop the vehicle
    public void stop() {
        System.out.println(make + " " + model + " is stopping.");
    }
    
    // Getter for make
    public String getMake() {
        return make;
    }

    // Getter for model
    public String getModel() {
        return model;
    }
}
