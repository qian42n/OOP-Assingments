import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class VehicleManagerTest {
    @Test
    public void testSingletonInstance() {
        VehicleManager instance1 = VehicleManager.getInstance();
        VehicleManager instance2 = VehicleManager.getInstance();
        assertEquals(instance1, instance2, "VehicleManager should be a singleton");
    }

    @Test
    public void testAddVehicle() {
        VehicleManager manager = VehicleManager.getInstance();
        Vehicle car = new Car();
        manager.addVehicle(car);
        assertTrue(manager.getVehicles().contains(car), "Vehicle should be successfully added to the manager");
    }
}