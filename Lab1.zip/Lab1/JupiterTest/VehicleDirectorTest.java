import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class VehicleDirectorTest {
    @Test
    public void testConstructVehicle() {
        VehicleBuilder carBuilder = new CarBuilder();
        VehicleDirector director = new VehicleDirector(carBuilder);
        Vehicle car = director.constructVehicle();
        assertNotNull(car, "Vehicle should be successfully constructed");
        assertEquals("Car Engine", car.getEngine(), "Vehicle should have the correct engine");
    }
}