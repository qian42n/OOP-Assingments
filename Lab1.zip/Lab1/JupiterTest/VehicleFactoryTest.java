import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class VehicleFactoryTest {
    @Test
    public void testCreateVehicle() {
        Vehicle car = VehicleFactory.createVehicle("car");
        assertTrue(car instanceof Car, "A Car instance should be created");

        Vehicle motorcycle = VehicleFactory.createVehicle("motorcycle");
        assertTrue(motorcycle instanceof Motorcycle, "A Motorcycle instance should be created");
    }
}