package org.cst8288Lab2;

import org.cst8288Lab2.dao.CourseDAO;
import org.cst8288Lab2.dao.StudentDAO;
import org.cst8288Lab2.models.Course;
import org.cst8288Lab2.models.Student;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public class BulkImportApp {
    private static final String CSV_FILE_PATH = "data/bulk-import.csv";
    private static List<String> errorList = new ArrayList<>();

    public static void main(String[] args) {
        // Load database properties
        Properties dbProperties = new Properties();
        try {
            dbProperties.load(new FileReader("data/database.properties"));
        } catch (IOException e) {
            System.err.println("Error loading database properties: " + e.getMessage());
            return;
        }

        String dbUrl = "jdbc:" + dbProperties.getProperty("db") + "://" +
                dbProperties.getProperty("host") + ":" +
                dbProperties.getProperty("port") + "/" +
                dbProperties.getProperty("name");
        String user = dbProperties.getProperty("user");
        String password = dbProperties.getProperty("pass");

        try (Connection connection = DriverManager.getConnection(dbUrl, user, password)) {
            StudentDAO studentDAO = new StudentDAO(connection);
            CourseDAO courseDAO = new CourseDAO(connection);

            // Read CSV file
            int studentCount = 0; // Counter for successfully added students
            int courseCount = 0; // Counter for successfully added courses

            try (BufferedReader br = new BufferedReader(new FileReader(CSV_FILE_PATH))) {
                String line;
                while ((line = br.readLine()) != null) {
                    String[] fields = line.split(","); // Assuming CSV is comma-separated

                    if (isValid(fields)) {
                        // Create Student and Course objects
                        Student student = new Student(Integer.parseInt(fields[0]), fields[1], fields[2]);
                        Course course = new Course(fields[3], fields[4], Integer.parseInt(fields[5]), Integer.parseInt(fields[6]));

                        // Insert into database
                        studentDAO.addStudent(student);
                        courseDAO.addCourse(course);

                        // Increment counters
                        studentCount++;
                        courseCount++;
                    } else {
                        errorList.add(line); // Add invalid line to error list
                    }
                }
            } catch (IOException e) {
                System.err.println("Error reading CSV file: " + e.getMessage());
            }

            // Generate reports
            generateSuccessReport(studentCount, courseCount);
            generateErrorReport(errorList);
        } catch (Exception e) {
            System.err.println("Database connection error: " + e.getMessage());
        }
    }

    private static boolean isValid(String[] fields) {
        // Implement your validation logic here
        // Validate studentId, courseId, term, year
        return true; // Return true if valid, false otherwise
    }

    private static void generateSuccessReport(int studentCount, int courseCount) {
        String reportFilePath = "data/import-report.md";
        StringBuilder reportContent = new StringBuilder();

        // Get current date and time
        String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));

        reportContent.append("# Import Success Report\n");
        reportContent.append("Date and Time: ").append(timestamp).append("\n\n");
        reportContent.append("## Summary\n");
        reportContent.append("- Number of Students Added: ").append(studentCount).append("\n");
        reportContent.append("- Number of Courses Added: ").append(courseCount).append("\n");

        // Write to file
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(reportFilePath))) {
            writer.write(reportContent.toString());
            System.out.println("Success report generated: " + reportFilePath);
        } catch (IOException e) {
            System.err.println("Error writing success report: " + e.getMessage());
        }
    }

    private static void generateErrorReport(List<String> errorList) {
        String reportFilePath = "data/error-report.md";
        StringBuilder reportContent = new StringBuilder();

        reportContent.append("# Error Report\n\n");
        reportContent.append("## Invalid Entries\n");

        // List the errors
        for (String error : errorList) {
            reportContent.append("- ").append(error).append("\n");
        }

        // Write to file
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(reportFilePath))) {
            writer.write(reportContent.toString());
            System.out.println("Error report generated: " + reportFilePath);
        } catch (IOException e) {
            System.err.println("Error writing error report: " + e.getMessage());
        }
    }
}
