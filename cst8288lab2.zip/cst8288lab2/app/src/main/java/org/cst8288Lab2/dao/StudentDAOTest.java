package org.cst8288Lab2.dao;

import org.cst8288Lab2.models.Student;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import static org.junit.jupiter.api.Assertions.*;

public class StudentDAOTest {
    private Connection connection;
    private StudentDAO studentDAO;

    @BeforeEach
    public void setUp() throws SQLException {
        // Set up database connection for testing
        String dbUrl = "jdbc:mysql://localhost:3306/labdatabase";
        String user = "root";
        String password = "password"; // Update as per your credentials
        connection = DriverManager.getConnection(dbUrl, user, password);
        studentDAO = new StudentDAO(connection);
    }

    @Test
    public void testAddStudent() throws SQLException {
        Student student = new Student(123456789, "John", "Doe");
        studentDAO.addStudent(student);
        Student retrievedStudent = studentDAO.getStudentById(123456789);
        assertEquals("John", retrievedStudent.getFirstName());
        assertEquals("Doe", retrievedStudent.getLastName());
    }

    @Test
    public void testGetAllStudents() throws SQLException {
        assertNotNull(studentDAO.getAllStudents());
    }

    @Test
    public void testUpdateStudent() throws SQLException {
        Student student = new Student(123456789, "John", "Doe");
        studentDAO.addStudent(student);
        student.setFirstName("Jane");
        studentDAO.updateStudent(student);
        assertEquals("Jane", studentDAO.getStudentById(123456789).getFirstName());
    }

    @Test
    public void testDeleteStudent() throws SQLException {
        Student student = new Student(123456789, "John", "Doe");
        studentDAO.addStudent(student);
        studentDAO.deleteStudent(123456789);
        assertNull(studentDAO.getStudentById(123456789));
    }
}
