package org.cst8288Lab2.dao;

import org.cst8288Lab2.models.Course;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import static org.junit.jupiter.api.Assertions.*;

public class CourseDAOTest {
    private Connection connection;
    private CourseDAO courseDAO;

    @BeforeEach
    public void setUp() throws SQLException {
        // Set up database connection for testing
        String dbUrl = "jdbc:mysql://localhost:3306/labdatabase";
        String user = "root";
        String password = "password"; // Update as per your credentials
        connection = DriverManager.getConnection(dbUrl, user, password);
        courseDAO = new CourseDAO(connection);
    }

    @Test
    public void testAddCourse() throws SQLException {
        Course course = new Course("CSE1234", "Introduction to Programming", 1, 2024);
        courseDAO.addCourse(course);
        Course retrievedCourse = courseDAO.getCourseById("CSE1234");
        assertEquals("Introduction to Programming", retrievedCourse.getCourseName());
    }

    @Test
    public void testGetAllCourses() throws SQLException {
        assertNotNull(courseDAO.getAllCourses());
    }

    @Test
    public void testUpdateCourse() throws SQLException {
        Course course = new Course("CSE1234", "Introduction to Programming", 1, 2024);
        courseDAO.addCourse(course);
        course.setCourseName("Advanced Programming");
        courseDAO.updateCourse(course);
        assertEquals("Advanced Programming", courseDAO.getCourseById("CSE1234").getCourseName());
    }

    @Test
    public void testDeleteCourse() throws SQLException {
        Course course = new Course("CSE1234", "Introduction to Programming", 1, 2024);
        courseDAO.addCourse(course);
        courseDAO.deleteCourse("CSE1234");
        assertNull(courseDAO.getCourseById("CSE1234"));
    }
}
