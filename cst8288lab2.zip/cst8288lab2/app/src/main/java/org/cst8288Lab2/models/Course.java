package org.cst8288Lab2.models;

public class Course {
    private String courseId;
    private String courseName;
    private String term;
    private int year;

    // Constructor
    public Course(String courseId, String courseName, String term, int year) {
        this.courseId = courseId;
        this.courseName = courseName;
        this.term = term;
        this.year = year;
    }

    // Getters and Setters
    public String getCourseId() {
        return courseId;
    }

    public void setCourseId(String courseId) {
        this.courseId = courseId;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public String getTerm() {
        return term;
    }

    public void setTerm(String term) {
        this.term = term;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    @Override
    public String toString() {
        return "Course{" +
                "courseId='" + courseId + '\'' +
                ", courseName='" + courseName + '\'' +
                ", term='" + term + '\'' +
                ", year=" + year +
                '}';
    }
}
