package org.cst8288Lab2;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class DataValidationTest {

    @Test
    public void testValidStudentId() {
        assertTrue(BulkImportApp.isValidStudentId("123456789"));
        assertFalse(BulkImportApp.isValidStudentId("12345"));
        assertFalse(BulkImportApp.isValidStudentId("12345678A"));
    }

    @Test
    public void testValidCourseId() {
        assertTrue(BulkImportApp.isValidCourseId("CSE1234"));
        assertFalse(BulkImportApp.isValidCourseId("123CSE4"));
        assertFalse(BulkImportApp.isValidCourseId("CSE12345"));
    }

    @Test
    public void testValidTerm() {
        assertTrue(BulkImportApp.isValidTerm("WINTER"));
        assertFalse(BulkImportApp.isValidTerm("SPRING"));
    }

    @Test
    public void testValidYear() {
        assertTrue(BulkImportApp.isValidYear("2024"));
        assertFalse(BulkImportApp.isValidYear("202"));
    }
}
