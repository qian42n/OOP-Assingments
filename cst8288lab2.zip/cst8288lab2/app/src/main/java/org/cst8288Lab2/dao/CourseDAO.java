package org.cst8288Lab2.dao;

import org.cst8288Lab2.models.Course;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CourseDAO {
    private final Connection connection;

    public CourseDAO(Connection connection) {
        this.connection = connection;
    }

    // Create a new course record
    public void addCourse(Course course) throws SQLException {
        String query = "INSERT INTO course (courseId, courseName, term, year) VALUES (?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, course.getCourseId());
            stmt.setString(2, course.getCourseName());
            stmt.setInt(3, course.getTerm());
            stmt.setInt(4, course.getYear());
            stmt.executeUpdate();
        }
    }

    // Read course record by ID
    public Course getCourseById(String courseId) throws SQLException {
        String query = "SELECT * FROM course WHERE courseId = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, courseId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return new Course(rs.getString("courseId"), rs.getString("courseName"), rs.getInt("term"), rs.getInt("year"));
                }
            }
        }
        return null;
    }

    // Read all course records
    public List<Course> getAllCourses() throws SQLException {
        List<Course> courses = new ArrayList<>();
        String query = "SELECT * FROM course";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                courses.add(new Course(rs.getString("courseId"), rs.getString("courseName"), rs.getInt("term"), rs.getInt("year")));
            }
        }
        return courses;
    }

    // Update course record
    public void updateCourse(Course course) throws SQLException {
        String query = "UPDATE course SET courseName = ?, term = ?, year = ? WHERE courseId = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, course.getCourseName());
            stmt.setInt(2, course.getTerm());
            stmt.setInt(3, course.getYear());
            stmt.setString(4, course.getCourseId());
            stmt.executeUpdate();
        }
    }

    // Delete course record
    public void deleteCourse(String courseId) throws SQLException {
        String query = "DELETE FROM course WHERE courseId = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, courseId);
            stmt.executeUpdate();
        }
    }
}
