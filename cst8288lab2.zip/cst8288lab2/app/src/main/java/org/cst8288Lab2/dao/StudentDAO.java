package org.cst8288Lab2.dao;

import org.cst8288Lab2.models.Student;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class StudentDAO {
    private final Connection connection;

    public StudentDAO(Connection connection) {
        this.connection = connection;
    }

    // Create a new student record
    public void addStudent(Student student) throws SQLException {
        String query = "INSERT INTO student (studentId, firstName, lastName) VALUES (?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, student.getStudentId());
            stmt.setString(2, student.getFirstName());
            stmt.setString(3, student.getLastName());
            stmt.executeUpdate();
        }
    }

    // Read student record by ID
    public Student getStudentById(int studentId) throws SQLException {
        String query = "SELECT * FROM student WHERE studentId = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, studentId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return new Student(rs.getInt("studentId"), rs.getString("firstName"), rs.getString("lastName"));
                }
            }
        }
        return null;
    }

    // Read all student records
    public List<Student> getAllStudents() throws SQLException {
        List<Student> students = new ArrayList<>();
        String query = "SELECT * FROM student";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                students.add(new Student(rs.getInt("studentId"), rs.getString("firstName"), rs.getString("lastName")));
            }
        }
        return students;
    }

    // Update student record
    public void updateStudent(Student student) throws SQLException {
        String query = "UPDATE student SET firstName = ?, lastName = ? WHERE studentId = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, student.getFirstName());
            stmt.setString(2, student.getLastName());
            stmt.setInt(3, student.getStudentId());
            stmt.executeUpdate();
        }
    }

    // Delete student record
    public void deleteStudent(int studentId) throws SQLException {
        String query = "DELETE FROM student WHERE studentId = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, studentId);
            stmt.executeUpdate();
        }
    }
}
