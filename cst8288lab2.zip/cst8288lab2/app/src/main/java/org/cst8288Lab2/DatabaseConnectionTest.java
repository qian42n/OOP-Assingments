package org.cst8288Lab2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;
import java.io.FileInputStream;
import java.io.InputStream;

public class DatabaseConnectionTest {
    public static void main(String[] args) {
        Properties dbConnection = new Properties();

        try (InputStream input = new FileInputStream("data/database.properties")) {
            dbConnection.load(input);

            String url = "jdbc:" + dbConnection.getProperty("db") + "://"
                    + dbConnection.getProperty("host") + ":"
                    + dbConnection.getProperty("port") + "/"
                    + dbConnection.getProperty("name");

            String user = dbConnection.getProperty("user");
            String password = dbConnection.getProperty("pass");

            try (Connection conn = DriverManager.getConnection(url, user, password)) {
                if (conn != null) {
                    System.out.println("Connection to database established successfully!");
                } else {
                    System.out.println("Failed to establish connection to database.");
                }
            } catch (SQLException e) {
                System.out.println("Database connection error: " + e.getMessage());
                e.printStackTrace();
            }
        } catch (Exception e) {
            System.out.println("Error loading database properties: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
